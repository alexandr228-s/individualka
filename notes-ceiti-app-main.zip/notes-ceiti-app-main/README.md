# Notes — CEITI Desktop Application Project

Это учебный проект.  
Содержит:
- прототип Figma (light + dark)
- UML (Use Case + Activity)
- SRS
- описание приложения
- отчёт в формате DOCX

## Figma
https://www.figma.com/design/B68smatjRYbU2KKeeKJSKH/Untitled?m=auto&t=SUxy0CwUN2x7KnPd-1
## Автор
Vorobiov Serghei

## Преподаватель
Gairunova Natalia
